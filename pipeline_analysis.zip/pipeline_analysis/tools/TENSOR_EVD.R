
TENSOR.EVD <- function(K1, K2, ID_K1=NULL, ID_K2=NULL, threshold=0.95,
                       min.eigenvalue=.Machine$double.eps, path=".", verbose=FALSE){
    ## Produces eigenvectors of the kronecker product of G and O
    #  Retains the top eigenvectors that capture a proportion of variance >= threshold

    if(is.null(ID_K1)){
      if(is.null(rownames(K1))){
        rownames(K1) <- paste0(1:nrow(K1))
      }
      ID_K1 <- rep(rownames(K1), each=ncol(K2))
    }
    if(is.null(ID_K2)){
      if(is.null(rownames(K2))){
        rownames(K2) <- paste0(1:nrow(K2))
      }
      ID_K2 <- rep(rownames(K2), ncol(K1))
    }
    ID_K1 <- as.character(ID_K1)
    ID_K2 <- as.character(ID_K2)

    stopifnot(all(ID_K1 %in% rownames(K1)))
    stopifnot(all(ID_K2 %in% rownames(K2)))
    stopifnot(length(ID_K1) == length(ID_K2))

    EVD.K1 <- eigen(K1, symmetric=TRUE)
    EVD.K2 <- eigen(K2, symmetric=TRUE)

    INDEX <- data.frame(K1=match(ID_K1, rownames(K1)), K2=match(ID_K2, rownames(K2)))

    dyn.load(paste0(path,"/c_utils.so"))
    tmp <- .Call('get_tensor_evd', EVD.K1$vectors, EVD.K2$vectors,
                            EVD.K1$values, EVD.K2$values,
                            as.numeric(min.eigenvalue),
                            INDEX$K1-1L, INDEX$K2-1L,
                            as.numeric(threshold), verbose)
    dyn.unload(paste0(path,"/c_utils.so"))

    rownames(tmp[[2]]) <- paste0(ID_K1,":",ID_K2)


    return(list(values=tmp[[1]],
                vectors=tmp[[2]],
                totalVar=tmp[[3]]))
}


TENSOR.EVD_old <- function(G, O, ID_G=NULL, ID_O=NULL, threshold=0.95,
                        min.eigenvalue=.Machine$double.eps, path=".", verbose=FALSE){
    ## Produces eigenvectors of the kronecker product of G and O
    #  Retains the top eigenvectors that capture a proportion of variance >= threshold

    if(is.null(ID_G)){
      if(is.null(rownames(G))){
        rownames(G) <- paste0(1:nrow(G))
      }
      ID_G <- rep(rownames(G), each=ncol(O))
    }
    if(is.null(ID_O)){
      if(is.null(rownames(O))){
        rownames(O) <- paste0(1:nrow(O))
      }
      ID_O <- rep(rownames(O), ncol(G))
    }
    ID_G <- as.character(ID_G)
    ID_O <- as.character(ID_O)

    stopifnot(all(ID_G %in% rownames(G)))
    stopifnot(all(ID_O %in% rownames(O)))
    stopifnot(length(ID_G) == length(ID_O))

    EVD.G <- eigen(G, symmetric=TRUE)
    EVD.O <- eigen(O, symmetric=TRUE)

    INDEX <- data.frame(G=match(ID_G, rownames(G)), O=match(ID_O, rownames(O)))

    dyn.load(paste0(path,"/c_utils.so"))
    tmp <- .Call('get_tensor_evd', EVD.G$vectors, EVD.O$vectors,
                            EVD.G$values, EVD.O$values,
                            as.numeric(min.eigenvalue), INDEX$G-1L, INDEX$O-1L,
                            as.numeric(threshold), verbose)
    dyn.unload(paste0(path,"/c_utils.so"))

    index <- (tmp[[1]]+1)[seq(tmp[[2]])]
    totalVar <- tmp[[3]]
    namesPC <- paste0((tmp[[4]]+1)[index],"_",(tmp[[5]]+1)[index])
    INFO <- data.frame(eigenvalue=tmp[[6]][index],Var=tmp[[7]][index], propVar=tmp[[7]][index]/totalVar)

    rownames(tmp[[8]]) <- paste0(ID_G,":",ID_O)
    colnames(tmp[[8]]) <- namesPC

    return(list(PC=tmp[[8]], INFO=INFO, totalVar=totalVar))
}
