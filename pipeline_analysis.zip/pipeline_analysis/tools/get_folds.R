
get_folds <- function(x, nfolds=10, seed=1234){
  ID <- names(table(x))
  nID <- length(ID)
  folds <- rep(seq(1:nfolds), ceiling(nID/nfolds))[1:nID]

  set.seed(seed)
  folds <- sample(folds)

  out <- rep(NA, length(x))
  for(i in 1:nfolds){
    index <- x %in% ID[folds == i]
    out[index] <- i
  }
  out
}
