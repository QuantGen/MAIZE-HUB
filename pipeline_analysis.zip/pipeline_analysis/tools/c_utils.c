#include <R.h>
#include <stdio.h>
#include <Rmath.h>
#include <Rinternals.h>
#include <Rdefines.h>
#include <string.h>
#include <R_ext/Lapack.h>

// ----------------------------------------------------------
// Return sorted (descendant order) indices for a vector of
// numeric values. The ordered position of the element k,
// values[k], is found by comparing with the (ordered) values
// of the previous k-1 values. This is, by finding the last
// index 'j' (j=0,1,...,k) such that
//                values[index[j]] > values[k]
// where 'index' contains the ordered indices for the first
//        k elements of 'values': values[0],...,values[k-1]
// The new vector with sorted indices will contain the k+1
// elements:
//    index[0],...,index[j-1], k, index[j],...,index[k-1]
// ----------------------------------------------------------
void append_to_sorted_vector_(int k, double *values, int *index)
{
  int j;

  if(k==0){
    index[0] = k;
  }else{
    j=0;
    while(values[index[j]]>values[k]){
      j++;
      if(j == k){
        break;
      }
    }
    if(j < k){
      memmove(index + j+1, index + j, (k-j)*sizeof(int));
    }
    index[j]=k;
  }
}

//==============================================================
//  VK1:       Eigenvectors of K1
//  VK2:       Eigenvectors of K2
//  valuesK1:  Eigenvalues of K1
//  valuesK2:  Eigenvalues of K2
//  minvalue:  Minimum acepted value for the kronecker eigenvalues
//             (i.e., valuesK1[i]*valuesK2[j])
//  indexK1:   Which elements from K1 are included in the tensor, zero based
//  indexK2:   which elements from K2 are included in the tensor, zero based
//  threshold: Maximum percentage of variance explained
//==============================================================
SEXP get_tensor_evd(SEXP VK1_, SEXP VK2_, SEXP valuesK1_, SEXP valuesK2_,
             SEXP minvalue_, SEXP indexK1_, SEXP indexK2_,
             SEXP threshold_, SEXP verbose_)
{
    int n, nK1, nK2;
    int i, j, k;
    int cont, verbose;
    double *VK2, *VK1, *valuesK1, *valuesK2;
    double *vK1i, *vK2i;
    int *indexK1, *indexK2;
    double minvalue, threshold;
    SEXP list, dimnames;

    n=XLENGTH(indexK1_); // should be the same as XLENGTH(indexK2_)
    nK1=XLENGTH(valuesK1_);
    nK2=XLENGTH(valuesK2_);
    minvalue=NUMERIC_VALUE(minvalue_);
    threshold=NUMERIC_VALUE(threshold_);
    verbose=asLogical(verbose_);
    double eps = DBL_EPSILON*100;
    int nmap=nK1*nK2;

    PROTECT(VK1_=AS_NUMERIC(VK1_));
    VK1=NUMERIC_POINTER(VK1_);

    PROTECT(VK2_=AS_NUMERIC(VK2_));
    VK2=NUMERIC_POINTER(VK2_);

    PROTECT(valuesK1_=AS_NUMERIC(valuesK1_));
    valuesK1=NUMERIC_POINTER(valuesK1_);

    PROTECT(valuesK2_=AS_NUMERIC(valuesK2_));
    valuesK2=NUMERIC_POINTER(valuesK2_);

    PROTECT(indexK1_=AS_INTEGER(indexK1_));
    indexK1=INTEGER_POINTER(indexK1_);

    PROTECT(indexK2_=AS_INTEGER(indexK2_));
    indexK2=INTEGER_POINTER(indexK2_);

    double *values0=(double *) R_alloc(nmap, sizeof(double));
    double *w0=(double *) R_alloc(nmap, sizeof(double));
    int *order=(int *) R_alloc(nmap, sizeof(int));
    int *K1i=(int *) R_alloc(nmap, sizeof(int));
    int *K2i=(int *) R_alloc(nmap, sizeof(int));

    // Get the PC's variances and total variance from the full Kronecker
    // The full design Kronecker has nK1*nK2 rows, positions will be saved in K1i and K2i
    // The variance of the tensor PCs are obtained as the product valuesK1[i]*valuesK2[j]
    // They will be descendantly sorted to return the one with highest variance first
    // until the one that jointly explains certain proportion of total variance
    if(verbose){
      Rprintf(" Calculating tensor variances (n=%d x %d=%d) ...\n",nK1,nK2,nmap);
    }
    double totalvar=0;
    cont=0;
    for(i=0; i<nK1; i++)  // loop over the rows of MAP
    {
      for(j=0; j<nK2; j++)
      {
        K1i[cont] = i;  // Storage the Kronecker positions for K1
        K2i[cont] = j;  // Storage the Kronecker positions for K2

        w0[cont] = 0;
      	for(k=0; k<n; k++){  // loop over the rows of the tensor to get tensor norms
      		w0[cont] += pow(VK1[nK1*i+indexK1[k]]*VK2[nK2*j+indexK2[k]],2);
      	}
        values0[cont] = valuesK1[i]*valuesK2[j]*w0[cont];
        if(values0[cont] < minvalue){
          values0[cont] = 0;
        }
    	  totalvar += values0[cont];

        // Keep track of the ordered variances
        append_to_sorted_vector_(cont, values0, order);
        cont++;
      }
    }

    // Get the number of PC that accumulated certain desired variance
    double cumvar = 0;
    int nPC = 0;
    for(i=0; i<nmap; i++)  // loop over the rows of MAP
    {
      cumvar += values0[order[i]]/totalvar;
      if(cumvar >= threshold - eps){
        nPC = i+1;
        break;
      }
    }
    nPC = (nPC ==  0) ? nmap : nPC;

    if(verbose){
      Rprintf(" Selected %d tensor eigenvectors explaining %.1f percent of the variance=%f\n",nPC,100*cumvar,totalvar);
    }

    // Output objects
    SEXP vectors_ = PROTECT(allocMatrix(REALSXP, n, nPC));
    double *vectors=NUMERIC_POINTER(vectors_);

    SEXP values_ = PROTECT(allocVector(REALSXP, nPC));
    double *values=NUMERIC_POINTER(values_);

    SEXP colnames_ = PROTECT(allocVector(STRSXP, nPC));

    if(verbose){
      Rprintf(" Obtaining tensor eigenvectors ...\n");
    }
    // The ith Tensor Eigenvector is formed by the product of the corresponding
    // Eigenvectors of K1 and K2 (positions in K1i and K2i) that were previously
    // sorted by the Tensor variance.
    // Only those entries of the selected Eigenvectors of K1 and K2 that are in
    // the Tensor (provided by indexK1 and indexK2) will enter in the dot product
    char name1[10], name2[10];
    double w;
    for(i=0; i<nPC; i++)  // loop over the rows of the (ordered) MAP
    {
      w = w0[order[i]];
      values[i] = values0[order[i]];
      vK1i = VK1 + nK1*K1i[order[i]];  // ith ordered column of VK1
      vK2i = VK2 + nK2*K2i[order[i]];  // ith ordered column of VK2
      for(k=0; k<n; k++){  // loop over the rows of the Hadamard
        vectors[(long long)n*(long long)i + (long long)k] = vK1i[indexK1[k]]*vK2i[indexK2[k]]/sqrt(w);
    	}
      // Colnames
      sprintf(name1,"%d",K1i[order[i]]+1);
      strcat(name1, "_");
      sprintf(name2,"%d",K2i[order[i]]+1);
      SET_STRING_ELT(colnames_,i,mkChar(strcat(name1, name2)));
    }

    if(verbose){
      Rprintf(" Done!\n");
    }

    // Set dimnames
    PROTECT(dimnames = allocVector(VECSXP, 2));
    SET_VECTOR_ELT(dimnames, 0, R_NilValue);
    SET_VECTOR_ELT(dimnames, 1, colnames_);
    setAttrib(vectors_, R_DimNamesSymbol, dimnames);

    PROTECT(list = allocVector(VECSXP, 3));
    SET_VECTOR_ELT(list, 0, values_);
    SET_VECTOR_ELT(list, 1, vectors_);
    SET_VECTOR_ELT(list, 2, ScalarReal(totalvar));
    UNPROTECT(11);

    return(list);
}

//==============================================================
// This a developing version
SEXP get_tensor_evd_old(SEXP VK1_, SEXP VK2_, SEXP valuesK1_, SEXP valuesK2_,
             SEXP minvalue_, SEXP indexK1_, SEXP indexK2_,
             SEXP threshold_, SEXP verbose_)
{
    int n, nmap, nK1, nK2;
    int i, j, k;
    int cont, verbose;
    double *VK2, *VK1, *valuesK1, *valuesK2, *values0;
    double *vK1i, *vK2i;
    int *order, *indexK1, *indexK2;
    double minvalue, threshold;
    SEXP list, order_;

    n=XLENGTH(indexK1_); // should be the same as XLENGTH(indexK2_)
    nK1=XLENGTH(valuesK1_);
    nK2=XLENGTH(valuesK2_);
    minvalue=NUMERIC_VALUE(minvalue_);
    threshold=NUMERIC_VALUE(threshold_);
    verbose=asLogical(verbose_);
    double eps = DBL_EPSILON*100;
    nmap=nK1*nK2;

    PROTECT(VK1_=AS_NUMERIC(VK1_));
    VK1=NUMERIC_POINTER(VK1_);

    PROTECT(VK2_=AS_NUMERIC(VK2_));
    VK2=NUMERIC_POINTER(VK2_);

    PROTECT(valuesK1_=AS_NUMERIC(valuesK1_));
    valuesK1=NUMERIC_POINTER(valuesK1_);

    PROTECT(valuesK2_=AS_NUMERIC(valuesK2_));
    valuesK2=NUMERIC_POINTER(valuesK2_);

    PROTECT(indexK1_=AS_INTEGER(indexK1_));
    indexK1=INTEGER_POINTER(indexK1_);

    PROTECT(indexK2_=AS_INTEGER(indexK2_));
    indexK2=INTEGER_POINTER(indexK2_);

    values0=(double *) R_alloc(nmap, sizeof(double));

    order_=PROTECT(allocVector(INTSXP, nmap));
    order=INTEGER_POINTER(order_);

    // Output objects
    SEXP K1i_ = PROTECT(allocVector(INTSXP, nmap));
    int *K1i=INTEGER_POINTER(K1i_);

    SEXP K2i_ = PROTECT(allocVector(INTSXP, nmap));
    int *K2i=INTEGER_POINTER(K2i_);

    SEXP varPC_ = PROTECT(allocVector(REALSXP, nmap));
    double *varPC=NUMERIC_POINTER(varPC_);

    SEXP w_ = PROTECT(allocVector(REALSXP, nmap));
    double *w=NUMERIC_POINTER(w_);

    // Get the PC's variances and total variance from the full Kronecker
    // The full design Kronecker has nK1*nK2 rows, positions will be saved in K1i and K2i
    // The variance of the tensor PCs are obtained as the product valuesK1[i]*valuesK2[j]
    // They will be descendantly sorted to return the one with highest variance first
    // until the one that jointly explains certain proportion of total variance
    if(verbose){
      Rprintf(" Calculating tensor PC variances (n=%d x %d=%d) ...\n",nK1,nK2,nmap);
    }
    //double tensorvar=0;
    double totalvar=0;
    cont=0;
    for(i=0; i<nK1; i++)  // loop over the rows of MAP
    {
      for(j=0; j<nK2; j++)
      {
        K1i[cont] = i;  // Storage the Kronecker positions for K1
        K2i[cont] = j;  // Storage the Kronecker positions for K2
        values0[cont] = valuesK1[i]*valuesK2[j];
        if(values0[cont] < minvalue){
          values0[cont] = 0;
        }
        w[cont] = 0;
      	for(k=0; k<n; k++){  // loop over the rows of the tensor
      		w[cont] += pow(VK1[nK1*i+indexK1[k]]*VK2[nK2*j+indexK2[k]],2);
      	}
    	  varPC[cont] = values0[cont]*w[cont];
    	  totalvar += varPC[cont];

        // Keep track of the ordered variances
        append_to_sorted_vector_(cont, varPC, order);
        //append_to_sorted_vector_(cont, values0, order);
        cont++;
      }
    }

    // Get the number of PC that accumulated certain desired variance
    double cumvar = 0;
    int nPC = 0;
    for(i=0; i<nmap; i++)  // loop over the rows of MAP
    {
      cumvar += varPC[order[i]]/totalvar;
      if(cumvar >= threshold - eps){
        nPC = i+1;
        break;
      }
    }
    nPC = (nPC ==  0) ? nmap : nPC;

    if(verbose){
      Rprintf(" Selected %d PCs explaining %.1f percent of the total variance=%f\n",nPC,100*cumvar,totalvar);
    }

    SEXP vectors_ = PROTECT(allocMatrix(REALSXP, n, nPC));
    double *vectors=NUMERIC_POINTER(vectors_);

    SEXP values_ = PROTECT(allocVector(REALSXP, nPC));
    double *values=NUMERIC_POINTER(values_);

    if(verbose){
      Rprintf(" Obtaining tensor PCs ...\n");
    }
    // The ith Tensor Eigenvector is formed by the product of the corresponding
    // Eigenvectors of K1 and K2 (positions in K1i and K2i) that were previously
    // sorted by the Tensor variance.
    // Only those entries of the selected Eigenvectors of K1 and K2 that are in
    // the Tensor (provided by indexK1 and indexK2) will enter in the dot product
    double w0;
    for(i=0; i<nPC; i++)  // loop over the rows of the (ordered) MAP
    {
      w0=w[order[i]];
      //values[i] = values0[order[i]];
      values[i] = varPC[order[i]];
      vK1i = VK1 + nK1*K1i[order[i]];  // ith ordered column of VK1
      vK2i = VK2 + nK2*K2i[order[i]];  // ith ordered column of VK2
      for(k=0; k<n; k++){  // loop over the rows of the Hadamard
    		//vectors[(long long)n*(long long)i + (long long)k] = vK1i[indexK1[k]]*vK2i[indexK2[k]];
        vectors[(long long)n*(long long)i + (long long)k] = vK1i[indexK1[k]]*vK2i[indexK2[k]]/sqrt(w0);
    	}
    }
    if(verbose){
      Rprintf(" Done!\n");
    }

    PROTECT(list = allocVector(VECSXP, 7));
    SET_VECTOR_ELT(list, 0, order_);
    SET_VECTOR_ELT(list, 1, ScalarReal(totalvar));
    SET_VECTOR_ELT(list, 2, K1i_);
    SET_VECTOR_ELT(list, 3, K2i_);
    SET_VECTOR_ELT(list, 4, w_);
    SET_VECTOR_ELT(list, 5, values_);
    SET_VECTOR_ELT(list, 6, vectors_);
    UNPROTECT(14);

    return(list);
}
