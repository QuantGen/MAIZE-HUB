

get_variance_components <- function(fm, comps, nIter = 1500, burnIn = 500, thin = 5){

  n1 <- nIter/thin
  n2 <- (nIter-burnIn)/thin

  if(is.null(names(comps))){
    names(comps) <- comps
  }

  mm <- rep(NA, length(comps)+1)
  names(mm) <- c(comps,"Error")

  flagYL <- FALSE
  namesYL <- c("YEAR","LOC","YL")
  FF <- vector("list", 3)
  names(FF) <- namesYL
  if(all(namesYL %in% comps)){
    tmp <- max(which(names(mm) %in% namesYL))
    mm <- c(mm[1:tmp],'(Total YL)'=NA, mm[(tmp+1):length(mm)])
    FF <- list(YEAR=NULL, LOC=NULL, YL=NULL)
    flagYL <- TRUE
  }

  ss <- mm[]
  Effect <- c()

  for(i in seq_along(comps)){
    comp0 <- as.vector(comps[i])

    filename <- fm$ETA[[comp0]]$NamefileOut

    isRandom <- !is.null(as.vector(fm$ETA[[comp0]]$df0)) & !is.null(as.vector(fm$ETA[[comp0]]$S0))
    isRandom <- isRandom & (length(as.vector(fm$ETA[[comp0]]$SD.varB))>0)

    if(isRandom){
      filename <- gsub("varB","b",filename)
      filename <- gsub("dat$","bin",filename)

      if(file.exists(filename)){
        B <- as.matrix(readBinMat(filename))
      }else{
        message("File does not exists for component ",comp0)
      }
    }else{
      if(file.exists(filename)){
        B <- as.matrix(data.table::fread(filename,data.table=FALSE))
      }else{
        message("File does not exists for component ",comp0)
      }
      if(nrow(B)!=n2){
        message("Dropped first ",n1-n2," rows of B for component '",comp0,"'")
        B <- B[-seq(n1-n2), , drop=F]
      }
    }

    run <- paste0("ff <- tcrossprod(",names(comps[i]), ", B)")
    eval(parse(text=run))

    tmp <- apply(ff,2,var)
    mm[comp0] <- mean(tmp)
    ss[comp0] <- sd(tmp)

    if(flagYL & comp0%in%names(FF)){
      FF[[comp0]] <- ff
    }

    # Compute Effect
    b <- fm$ETA[[comp0]]$b
    run <- paste0("eff <- as.vector(",names(comps[i]), " %*% b)")
    eval(parse(text=run))
    Effect <- cbind(Effect,eff)

    message("Component=", comp0)
  }

  # Error variance
  B <- as.matrix(data.table::fread(paste0(dirname(filename),"/varE.dat"),
                 data.table=FALSE))
  if(nrow(B)!=n2){
    message("Dropped first ",n1-n2," rows of B for error component")
    B <- B[-seq(n1-n2), , drop=F]
  }
  mm['Error'] <- apply(B, 2, mean)
  ss['Error'] <- apply(B, 2, sd)

  if(flagYL){
    tmp <- unlist(lapply(FF,ncol))
    if(length(unique(tmp))>1){
      FF <- lapply(FF,function(x)x[,seq(min(tmp))])
    }
    ff0 <- Reduce("+",FF)
    tmp <- apply(ff0,2,var)
    mm['(Total YL)'] <- mean(tmp)
    ss['(Total YL)'] <- sd(tmp)
  }

  colnames(Effect) <- as.vector(comps)

  VC <- data.frame(source=names(mm),var=mm,sd=ss)
  rownames(VC) <- NULL

  return(list(VC=VC, Effect=Effect))

}
