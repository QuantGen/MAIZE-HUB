
#-------------------------------------------------------------------
# Pipeline to curate G2F data and to generate environmental covariates
# using APSIM model for each year-location in the G2F data
#-------------------------------------------------------------------

#-------------------------------------------------------------------
# Final OUTPUTs: PHENO.csv, GENO.csv, MAP.csv, ECOV.csv
#-------------------------------------------------------------------

The pipeline has the shown-below sequential structure with 7 modules where
the number preceding the name of the folder (e.g., '1_phenotypes') indicates
the sequence of the module.

Each module will produce either an intermediate file that will be used by
another module or a final output file (PHENO.csv, GENO.csv, MAP.csv, ECOV.csv).
Code to perform the task is stored in the subfolder 'code' within each module.
Final and intermediate files produced at each module will be saved in subfolder
'output' within each module.

[pipeline_ecov]
│
├── 1_phenotypes
│   ├── code                            # INPUT: phenotypic, metadata, agronomic data in 'source'
│   │   └── 1_get_phenotype.R           # Get phenotypic data for all year-locations
│   └── output                          # OUTPUT: PHENO.csv
├── 2_genotypes
│   ├── code                            # INPUT: genotypic data in 'source'
│   │   ├── 1_SNP_filter_codify.sub     # Codify and filter by NA and MAF of SNPs
│   │   └── 2_LD_prune_genotypes.R      # LD pruning of SNPs
│   └── output                          # OUTPUTs: GENO.csv, MAP.csv
├── 3_year_loc_summary
│   ├── code                            # INPUT: PHENO.csv
│   │   └── 1_year_location_summary.R   # Get year-location summary
│   └── output                          # OUTPUT: year_location_info.csv
├── 4_weather
│   ├── code                            # INPUT: year_location_info.csv
│   │   └── 1_get_met_apsim.R           # Download weather data for each year-location
│   └── output                          # OUTPUTs: [year-location name].met
├── 5_APSIM
│   ├── code                            # INPUTs: year_location_info.csv, [year-location name].met
│   │   ├── 1_apsim_sim.R               # Run the APSIM crop model for each year-location
│   │   └── 1_apsim_sim.sub             # Submission file for code
│   └── output                          # OUTPUTs: [year-location name].csv
├── 6_ecov
│   ├── code                            # INPUTs: [year-location name].csv
│   │   └── 1_get_env_cov.R             # Generate environmental covariates from APSIM outputs
│   └── output                          # OUTPUT: ECOV.csv
├── 7_GDD
│   └── code                            # INPUT/OUTPUT: PHENO.csv
│       └── 1_add_GDD_to_pheno.R        # Compute GDD flowering traits and add them to PHENO.csv
├── source                              # Data downloaded from G2F website (see below)
│   ├── Agronomic_information
│   ├── Genotype
│   ├── Metadata
│   └── Phenotype
└── tools                               # R-functions are used throughout the workflow
    ├── APSIM_functions.R
    ├── ecov_utils.R
    ├── Functions.R
    ├── LD_prune.R
    ├── read_metadata.R
    └── read_phenotype.R


Folder 'source' contains the data (phenotypic, metadata, and agronomic) downloaded
from the G2F website (https://www.genomes2fields.org/resources/) for all years available
since 2014.

These files are stored in their respective subfolders as

[source]
│
├── Agronomic_information
│   ├── g2f_2014_field_characteristics.csv
│   ├── g2f_2015_agronomic_information.csv
│   ├── g2f_2016_agronomic_information.csv
│   ├── g2f_2017_agronomic\ information.csv
│   ├── g2f_2018_agronomic\ information.csv
│   ├── g2f_2019_agronomic_information.csv
│   ├── g2f_2020_agronomic_information.csv
│   └── g2f_2021_agronomic_information.csv
├── Genotype
│   └── Hybrids_G2F_Genotype_Data_All_Years.vcf.zip
├── Metadata
│   ├── g2f_2014_field_characteristics.csv
│   ├── g2f_2015_field_metadata.csv
│   ├── g2f_2016_field_metadata.csv
│   ├── g2f_2017_field_metadata.csv
│   ├── g2f_2018_field_metadata.csv
│   ├── g2f_2019_field_metadata.csv
│   ├── g2f_2020_field_metadata.csv
│   ├── g2f_2021_field_metadata.csv
│   └── g2f_2022_field_metadata.csv
└── Phenotype
    ├── g2f_2014_hybrid_data_clean.csv
    ├── g2f_2015_hybrid_data_clean.csv
    ├── g2f_2016_hybrid_data_clean.csv
    ├── g2f_2017_hybrid_data_clean.csv
    ├── g2f_2018_hybrid_data_clean.csv
    ├── g2f_2019_phenotypic_clean_data.csv
    ├── g2f_2020_phenotypic_clean_data.csv
    └── g2f_2021_phenotypic_clean_data.csv
