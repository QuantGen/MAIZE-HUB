#=============================================================================
# Lastest version writen by Fernando Aguate.
# Edited by Marco Lopez Oct 10, 2022
#=============================================================================
# APSIM simulate function
#  To test:   replace_file = T; verbose = T; max_iter = 20
apsim_simulate <- function(parameters, sim_report=NULL, replace_file = T,
                           verbose = T, max_iter = 30, trim=TRUE) {
  require('apsimx')
  require('lubridate')
  require('soilDB')
  require('spData')
  require('odbc')
  require('lubridate')
  require('sf')

  # Default parameters
  def_parameters = list(
    sim_dir = '',
    sim_file_apsim = 'Maize.apsimx',
    sim_name = 'sim_example',
    lat = 30.7941,
    lon = -96.5775,
    plant_date = '2017-04-20',
    flower_date = 'default', # by default use the flower GDD; reruns the model to match the flowering date
    weather_file = 'met_example.met', # download weather data by default or if file does not exist
    weather_days_before = 90, # Weather data days before planting
    weather_dir = '', # Same as sim_dir by default
    fertilize_NO3N = 160, # unit: kg/ha
    plant_population = 6, # Unit: m^2
    gdd_juv = 210,
    gdd_gf = 510
  )

  # Parameters that were not define are set to default values
  for(i in seq_along(def_parameters)) if(!names(def_parameters)[i] %in% names(parameters)) parameters[[names(def_parameters)[i]]] <- def_parameters[[i]]
  # Fix NAs
  for(i in seq_along(def_parameters)) if(is.na(parameters[[names(def_parameters)[i]]])) parameters[[names(def_parameters)[i]]] <- def_parameters[[i]]

  if(parameters$weather_dir == '')  parameters$weather_dir <- parameters$sim_dir

  # Stop conditions
  stopif <- function(par_name, stop_message, parameters) if (is.na(parameters[[par_name]])) stop(stop_message)
  stopif('sim_dir', 'simulation directory (sim_dir) missing in parameters.', parameters)
  stopif('sim_name', 'simulation name (sim_name) missing in parameters.', parameters)
  stopif('lon', 'Location longitude (lon) missing in parameters.', parameters)
  stopif('lat', 'Location latitude (lat) missing in parameters.', parameters)
  stopif('plant_date', 'Planting date (plant_date) missing in parameters.', parameters)
  if(parameters$lat < 0){
     stop("Check this function if you are trying to make simulations in the southern hemisphere.",
      "\n Soil data and winter-summer cycles are set to work for the northern hemisphere only.")
  }

  # Plant date as date
  if(!is.Date(parameters$plant_date)) parameters$plant_date <- as.Date(parameters$plant_date)

  # Evaluate parameters
  for(i in seq_along(parameters)) assign(names(parameters)[i], parameters[[i]], env = .GlobalEnv )

  # Create simulation directory
  if(!dir.exists(sim_dir)) dir.create(sim_dir)

  # Copy file example to sim directory
  file_dir_name <- paste0(sim_dir, '/', sim_name, '.apsimx')
  if(!file.exists(file_dir_name) | replace_file) {
    ex_dir <- auto_detect_apsimx_examples()
    success <- file.copy(normalizePath(paste0(ex_dir, '/', sim_file_apsim)), file_dir_name, overwrite = T, recursive = F)
  }
  if(!success) stop('The APSIM file could not be created. Make sure you have APSIM Next Gen installed and have writing permissions in the specified folders.')
  sim_file <- basename(file_dir_name)

  # Clock period
  clock_period <- c(plant_date - weather_days_before, plant_date + (30 * 7))

  # Weather data
  weather_path <- paste0(weather_dir, '/', weather_file)
  weather_download <- !file.exists(weather_path) | parameters$weather_file == 'met_example.met'

  # Download weather data
  sim_coord <- c(lon, lat)
  if(weather_download){
    imet <- get_power_apsim_met(sim_coord, dates = clock_period)

    # Impute missing data
    for(w in which(is.na(imet[1,]))) imet[1, w] <- mean(imet[,w], na.rm = T)
    imet$radn <- ifelse(imet$radn == -99, NA, imet$radn)
    if(any(is.na(imet))) imet <- apsimx::impute_apsim_met(imet)

    weather <- imet
    write_apsim_met(weather, wrt.dir = weather_dir, filename = weather_file)
  }else{
    weather <- read.csv(weather_path, sep = ' ', skip = 8, check.names=F)
    wdates <- as.Date(NA)
    for(i in 1:nrow(weather)) wdates[i] <- as.Date(weather[i,2] - 1, origin = paste0(weather[i,1], '-01-01'))
    # Check for missing data
    index <- which(apply(weather,1,function(x)all(is.na(x[-c(1:2)]))))
    if(length(index)>0){
      wdates <- wdates[-index]
    }
    if(min(wdates) > clock_period[1]){
       stop('The start clock period is not contained in the weather data.')
    }
    if(max(wdates) < clock_period[2]){
      cat("The end clock period is not contained in the weather data.\n",
          "This value was set to the last weather data date:",as.character(max(wdates)),"\n")
      clock_period[2] <- max(wdates)
    }
  }
  # Set clock period
  edit_apsimx_new(sim_file, sim_dir, overwrite = T, verbose = F,
                  node = 'Clock', parm = c('Start', 'End'),
                  value = paste0(clock_period, 'T00:00:00'))

  # Assign weather data to the simulation file
  edit_apsimx_new(sim_file, sim_dir, overwrite=T, node='Weather',
                  value = normalizePath(paste0(weather_dir,'/',weather_file)), verbose=F)

  # Set sowing rules
  edit_apsimx_new(sim_file, sim_dir, overwrite = T, verbose = F,
                  node = 'Crop', parm = 'StartDate',
                  value = casefold(format(plant_date, '%d-%b')))

  edit_apsimx_new(sim_file, sim_dir, overwrite = T, verbose = F,
                  node = 'Crop', parm = 'EndDate',
                  value = casefold(format(plant_date + 1, '%d-%b')))

  edit_apsimx_new(sim_file, sim_dir, overwrite = T, verbose = F,
                  node = 'Crop', parm = 'MinESW', value = 0)

  edit_apsimx_new(sim_file, sim_dir, overwrite = T, verbose = F,
                  node = 'Crop', parm = 'MinRain', value = 0)

  # Set soil water parameters (Northern Hemisphere)
  edit_apsimx(sim_file, sim_dir, node = 'Soil', soil.child = 'SoilWater', overwrite = T,
              parm = 'SummerDate', value = '1-May', verbose = F)

  edit_apsimx(sim_file, sim_dir, node = 'Soil', soil.child = 'SoilWater', overwrite = T,
              parm = 'WinterDate', value = '1-Aug', verbose = F)

  edit_apsimx(sim_file, sim_dir, node = 'Soil', soil.child = 'SoilWater', overwrite = T,
              parm = 'SummerU', value = 1, verbose = F)

  # Set initial water to 50%
  edit_apsimx(sim_file, sim_dir, node = 'Soil', soil.child = 'InitialWater', overwrite = T,
              parm = 'FractionFull', value = 0.50, verbose = F)


  # Set plant population
  edit_apsimx_new(sim_file, sim_dir, overwrite = T, verbose = F,
                  node = 'Crop', parm = 'Population', value = plant_population)

  # Set initial fertilizer
  edit_apsimx_new(sim_file, sim_dir, overwrite = T, verbose = F,
                  node = 'Other', parm = 'SowingFertiliser', value = fertilize_NO3N,
                  parm.path = '.Simulations.Simulation.Field.SowingFertiliser.Amount')

  # Set report
  edit_apsimx_new(sim_file, sim_dir, overwrite = T, verbose = F,
                  node = 'Report', parm = 'EventNames', value = list('[Clock].EndOfDay'))

  if(is.null(sim_report)){
    sim_report <- list('[Clock].Today', '[Maize].Phenology.CurrentStageName', '[Phenology].ThermalTime', '[Maize].AboveGround.Wt',
                     '[Maize].Grain.Wt', '[SoilWater].CN2Bare', '[SoilWater].DiffusConst', '[SoilWater].DiffusSlope', '[SoilWater].Drainage',
                     '[SoilWater].Eo', '[SoilWater].Eos', '[SoilWater].Es', '[SoilWater].ESW', '[SoilWater].Flow', '[SoilWater].FlowNH4',
                     '[SoilWater].FlowNO3', '[SoilWater].FlowUrea', '[SoilWater].Flux', '[SoilWater].Infiltration', '[SoilWater].KLAT',
                     '[SoilWater].LateralFlow', '[SoilWater].LateralOutflow', '[SoilWater].LeachNH4', '[SoilWater].LeachNO3',
                     '[SoilWater].LeachUrea', '[SoilWater].PAW', '[SoilWater].PAWmm', '[SoilWater].Pond', '[SoilWater].PotentialInfiltration',
                     '[SoilWater].PotentialRunoff', '[SoilWater].PrecipitationInterception', '[SoilWater].Runoff', '[SoilWater].Runon',
                     '[SoilWater].Salb', '[SoilWater].SoluteFlowEfficiency', '[SoilWater].SoluteFluxEfficiency', '[SoilWater].SummerCona',
                     '[SoilWater].SummerU', '[SoilWater].SW', '[SoilWater].SWCON', '[SoilWater].SWmm', '[SoilWater].T', '[SoilWater].Thickness',
                     '[SoilWater].Water', '[SoilWater].WaterTable', '[SoilWater].WinterCona', '[SoilWater].WinterDate', '[SoilWater].WinterU',
                     '[Field].Maize.CoverGreen', '[Field].Maize.CoverTotal', '[Field].Maize.LAI', '[Maize].Phenology.AccumulatedTT')
  }

  edit_apsimx_new(sim_file, sim_dir, overwrite=T, verbose=F,
                  node='Report', parm='VariableNames', value=sim_report)

  # Set cultivar parameters
  edit_apsimx_new(sim_file, sim_dir, node='Cultivar', overwrite=T, verbose=F,
                  parm='Name', value='Custom')
  # Set the new cultivar as the planted one.
  edit_apsimx_new(sim_file, sim_dir, node='Crop', parm='CultivarName', overwrite=T,
                  value='Custom', verbose=F)

  # Set soil data
  ssurgo_data <- try(capture.output(get_ssurgo_soil_profile(lonlat=sim_coord)), silent=T)
  if(class(ssurgo_data) == 'try-error'){
    i <- 0
    while(class(ssurgo_data) == 'try-error') {
      sim_coord <- sim_coord + rnorm(1, 0, 0.005)
      ssurgo_data <- try(capture.output(get_ssurgo_soil_profile(lonlat=sim_coord)), silent=T)
      i <- i + 1
      cat('Attempt to get valid SSURGO data:', i, '\n')
    }
  }
  ssurgo_data <- get_ssurgo_soil_profile(lonlat = sim_coord)
  edit_apsimx_replace_soil_profile(sim_file, sim_dir, overwrite=TRUE,
                                   soil.profile = ssurgo_data[[1]], verbose=FALSE)

  # Set phenology
  if(flower_date == 'default'){
    list_gdd = list(paste0('[Phenology].Juvenile.Target.FixedValue = ', gdd_juv),
                    paste0('[Phenology].GrainFilling.Target.FixedValue = ', gdd_gf))

  }else{
    # Start wit default values of gdd_juv=210 and gdd_gf=510
    gdd_juv0 <- gdd_juv
    gdd_gf0 <- gdd_gf
    iter <- 1
    day_diff <- Inf
    while(abs(day_diff)>0 & iter<max_iter)
    {
      #gdd_gf <- round(gdd_gf0 * gdd_juv / gdd_juv0)
      gdd_gf <- gdd_juv + (gdd_gf0 - gdd_juv0)
      list_gdd = list(paste0('[Phenology].Juvenile.Target.FixedValue = ', gdd_juv),
                      paste0('[Phenology].GrainFilling.Target.FixedValue = ', gdd_gf))
      edit_apsimx_new(sim_file, sim_dir, node='Cultivar', parm='Command', overwrite=TRUE,
                      verbose=FALSE, value=list_gdd)

      tmp_sim <- apsimx(sim_file, sim_dir)[,c("Date", "Maize.Phenology.CurrentStageName", "Phenology.ThermalTime", "Maize.Phenology.AccumulatedTT")]
      simDate <- as.Date(tmp_sim$Date[tmp_sim$Maize.Phenology.CurrentStageName == 'Flowering'])
      if(verbose){
         cat("Iter=",iter, '. Juvenile = ', gdd_juv, ". Flowering:",as.character(simDate),'\n')
      }
      day_diff <- as.numeric(as.Date(flower_date) - simDate)
      if(abs(day_diff)==0){
        break
      }else{
        if(day_diff > 0){
           gdd_juv <- gdd_juv + 10
        }
        if(day_diff < 0){
          gdd_juv <- gdd_juv - 9
        }
      }

      if(gdd_juv < 100) break

      iter <- iter + 1
    }

    #gdd_gf <- round(gdd_gf0 * gdd_juv / gdd_juv0)
    gdd_gf <- gdd_juv + (gdd_gf0 - gdd_juv0)

    list_gdd = list(paste0('[Phenology].Juvenile.Target.FixedValue = ', gdd_juv),
                    paste0('[Phenology].GrainFilling.Target.FixedValue = ', gdd_gf))
  }
  edit_apsimx_new(sim_file, sim_dir, node='Cultivar', parm='Command', overwrite=TRUE,
                  verbose=FALSE, value = list_gdd)

  # Run simulation
  sim <- apsimx(sim_file, sim_dir, value = "report")

  # Format output
  sim <- sim[,!colnames(sim) %in% c("Date","CheckpointID","SimulationID","Zone","CatchmentArea")]
  colnames(sim)[grep("Maize.Grain.Wt",colnames(sim))] <- "yield"
  colnames(sim)[grep("Maize.AboveGround.Wt",colnames(sim))] <- "biomass"
  colnames(sim)[grep("Maize.Phenology.AccumulatedTT",colnames(sim))] <- "AccumulatedTT"
  colnames(sim)[grep("ThermalTime",colnames(sim))] <- "TT"
  colnames(sim)[grep("CurrentStageName",colnames(sim))] <- "Stage"
  colnames(sim) <- gsub("SoilWater.","",colnames(sim))
  colnames(sim) <- gsub("Field.Maize.","",colnames(sim))
  colnames(sim) <- gsub("SoluteFlowEfficiency","SolFlowEff",colnames(sim))
  colnames(sim) <- gsub("SoluteFluxEfficiency","SolFluxEff",colnames(sim))
  colnames(sim) <- gsub("PotentialInfiltration","PotInf",colnames(sim))
  colnames(sim) <- gsub("PotentialRunoff","PotRunoff",colnames(sim))
  colnames(sim) <- gsub("PrecipitationInterception","PrecInterc",colnames(sim))
  colnames(sim)[grep("Clock.Today",colnames(sim))] <- "Date"

  sim$Date <- as.Date(sim$Date)
  if(trim){
    if("Sowing" %in% sim$Stage){
      sim <- sim[sim$Date >= sim$Date[sim$Stage == "Sowing"],]
    }
    if("HarvestRipe" %in% sim$Stage){
      sim <- sim[sim$Date <= sim$Date[sim$Stage == "HarvestRipe"],]
    }
  }
  rownames(sim) <- NULL

  return(sim)
}

#=============================================================================
# Internal function

search_apsimx <- function(tmp, keyword, return_lvls = FALSE) {
  lvls <- vector()
  for (i in 1:5) {
    sapp <- sapply(tmp$Children, function(x) length(grep(keyword, unlist(capture.output(str(x))))) > 0)
    if (length(sapp) == 0) break
    if (length(sapp) == 1) if (!sapp) break
    lvls[i] <- which(sapp)
    tmp <- tmp$Children[[lvls[i]]]
  }
  if (return_lvls) {
    return(lvls)
  } else {
    return(tmp)
  }
}


#=============================================================================
# New version of edit APSIM

edit_apsimx_new <- function (file, src.dir = ".", wrt.dir = NULL,
                             node = c("Clock", 'Report', 'Cultivar',
                                      "Weather", "Soil", "SurfaceOrganicMatter",
                                      "MicroClimate", "Crop", "Manager", "Other"),
                             soil.child = c("Metadata", "Water", "SoilWater",
                                            "Organic", "Physical", "Analysis",
                                            "Chemical", "InitialWater", "Sample"),
                             manager.child = NULL, parm = NULL, value = NULL, overwrite = FALSE,
                             edit.tag = "-edited", parm.path = NULL, root, verbose = TRUE)
{
  #.check_apsim_name(file)
  if (missing(wrt.dir))
    wrt.dir <- src.dir
  file.names <- dir(path = src.dir, pattern = ".apsimx$",
                    ignore.case = TRUE)
  if (length(file.names) == 0) {
    stop("There are no .apsimx files in the specified directory to edit.")
  }
  node <- match.arg(node)
  soil.child <- match.arg(soil.child)
  edited.child <- "none"
  file <- match.arg(file, file.names)
  if (apsimx_filetype(file = file, src.dir = src.dir) != "json")
    stop("This function only edits JSON files")
  apsimx_json <- jsonlite::read_json(paste0(src.dir, "/",
                                            file))
  wcore <- grep("Core.Simulation", apsimx_json$Children)
  if (length(wcore) > 1) {
    if (missing(root)) {
      cat("Simulation structure: \n")
      str_list(apsimx_json)
      stop("more than one simulation found and no root node label has been specified \n select one of the children names above")
    }
    else {
      if (length(root) == 1) {
        wcore1 <- grep(as.character(root), apsimx_json$Children)
        if (length(wcore1) == 0 || length(wcore1) > 1)
          stop("no root node label found or root is not unique")
        parent.node <- apsimx_json$Children[[wcore1]]$Children
      }
      else {
        root.node.0.names <- sapply(apsimx_json$Children,
                                    function(x) x$Name)
        wcore1 <- grep(as.character(root[1]), root.node.0.names)
        root.node.0 <- apsimx_json$Children[[wcore1]]
        root.node.0.child.names <- sapply(root.node.0$Children,
                                          function(x) x$Name)
        wcore2 <- grep(as.character(root[2]), root.node.0.child.names)
        parent.node <- apsimx_json$Children[[wcore1]]$Children[[wcore2]]$Children
      }
    }
  }else {
    parent.node <- apsimx_json$Children[[wcore]]$Children
  }

  if (node == "Clock") {
    parm.choices <- c("Start", "End")
    parm <- match.arg(parm, choices = parm.choices, several.ok = TRUE)
    wlc <- function(x) grepl("Clock", x$Name)
    wlcl <- sapply(parent.node, FUN = wlc)
    start <- grep("Start", names(parent.node[wlcl][[1]]),
                  ignore.case = TRUE, value = TRUE)
    end <- grep("End", names(parent.node[wlcl][[1]]),
                ignore.case = TRUE, value = TRUE)
    if (length(parm) == 1) {
      if (parm == "Start") {
        parent.node[wlcl][[1]][start] <- value
      }
      if (parm == "End") {
        parent.node[wlcl][[1]][end] <- value
      }
    }
    if (length(parm) == 2) {
      if (parm[1] == "Start") {
        parent.node[wlcl][[1]][start] <- value[1]
      }
      if (parm[2] == "End") {
        parent.node[wlcl][[1]][end] <- value[2]
      }
    }
    apsimx_json$Children[[1]]$Children <- parent.node
  }
  if (node == "Weather") {
    wlw <- function(x) grepl("Weather", x$Name)
    wlwl <- sapply(parent.node, FUN = wlw)
    parent.node[wlwl][[1]]$FileName <- value
  }
  wcz <- grepl("Models.Core.Zone", parent.node)
  core.zone.node <- parent.node[wcz][[1]]$Children
  if (node == "Soil") {
    wsn <- grepl("Models.Soils.Soil", core.zone.node)
    soil.node <- core.zone.node[wsn]
    soil.node0 <- soil.node[[1]]$Children
    if (soil.child == "Metadata") {
      edited.child <- soil.child
      metadata.parms <- c("RecordNumber", "ASCOrder",
                          "ASCSubOrder", "SoilType", "LocalName",
                          "Site", "NearestTown", "Region",
                          "State", "Country", "NaturalVegetation",
                          "ApsoilNumber", "Latitude", "Longitude",
                          "LocationAccuracy", "DataSource",
                          "Comments")
      if (!all(parm %in% metadata.parms))
        stop("parm name(s) might be wrong")
      for (i in seq_along(parm)) {
        soil.node[[1]][[parm[i]]] <- value[i]
      }
    }
    if (soil.child == "Water") {
      edited.child <- soil.child
      wwn <- grep("^Water", sapply(soil.node[[1]]$Children, function(x) x$Name))
      soil.water.node <- soil.node[[1]]$Children[[wwn]]
      if (soil.water.node$Name != "Water") {
        stop("Wrong node (Soil Water)")
      }
      crop.parms <- c("XF", "KL", "LL")
      if (parm %in% crop.parms) {
        for (i in 1:length(soil.water.node$Children[[1]][[parm]])) {
          soil.water.node$Children[[1]][[parm]][[i]] <- value[i]
        }
      }
      else {
        for (i in 1:length(soil.water.node[[parm]])) {
          soil.water.node[[parm]][[i]] <- value[i]
        }
      }
      soil.node[[1]]$Children[[wwn]] <- soil.water.node
    }
    if (soil.child == "Physical") {
      wpn <- grep("^Physical", sapply(soil.node[[1]]$Children, function(x) x$Name))
      if (!is.list(value)) value <- as.list(value)
      depth_length <- length(soil.node[[1]]$Children[[wpn]]$Depth)
      if (length(value) != depth_length) value <- value[1:depth_length]
      soil.node[[1]]$Children[[wpn]][[parm]] <- value
    }
    if (soil.child == "SoilWater") {
      edited.child <- soil.child
      wswn <- grep("^SoilWater", sapply(soil.node[[1]]$Children,
                                        function(x) x$Name))
      soil.soilwater.node <- soil.node[[1]]$Children[[wswn]]
      soilwat.parms <- c("SummerDate", "SummerU",
                         "SummerCona", "WinterDate", "WinterU",
                         "WinterCona", "DiffusConst", "DiffusSlope",
                         "Salb", "CN2Bare", "CNRed",
                         "CNCov", "Slope", "DischargeWidth",
                         "CatchmentArea")
      if (parm %in% soilwat.parms) {
        for (i in seq_along(parm)) {
          soil.soilwater.node[[parm[i]]] <- value[i]
        }
      }
      else {
        if (!parm %in% c("SWCON", "KLAT"))
          stop("parameter is likely incorrect")
        for (i in 1:length(soil.soilwater.node[[parm]])) {
          soil.soilwater.node[[parm]][[i]] <- value[i]
        }
      }
      soil.node[[1]]$Children[[wswn]] <- soil.soilwater.node
    }
    if (soil.child == "Nitrogen") {
      wnn <- grepl("Nitrogen", soil.node0)
      soil.nitrogen.node <- soil.node0[wnn][[1]]
      for (i in 1:length(soil.nitrogen.node[[parm]])) {
        soil.nitrogen.node[[parm]][[i]] <- value[i]
      }
      soil.node[[1]]$Children[wnn][[1]] <- soil.nitrogen.node
    }
    if (soil.child == "Organic") {
      edited.child <- "Organic"
      wsomn <- grepl("Organic", soil.node0)
      soil.om.node <- soil.node0[wsomn][[1]]
      som.parms1 <- c("RootCN", "EnrACoeff",
                      "EnrBCoeff")
      if (parm %in% som.parms1) {
        soil.om.node[[parm]] <- value
      }
      else {
        for (i in 1:length(soil.om.node[[parm]])) {
          soil.om.node[[parm]][[i]] <- value[i]
        }
      }
      soil.node[[1]]$Children[wsomn][[1]] <- soil.om.node
    }
    if (soil.child == "Analysis" || soil.child == "Chemical") {
      edited.child <- soil.child
      wan <- grepl(soil.child, soil.node0)
      soil.analysis.node <- soil.node0[wan][[1]]
      #if (parm != "PH")
      #  stop("only PH can be edited, use 'edit_apsimx_replace_soil_profile instead")
      #if (parm == "PH") {
      for (i in 1:length(soil.analysis.node[[parm]])) {
        soil.analysis.node[[parm]][[i]] <- value[i]
        #  }
      }
      soil.node[[1]]$Children[wan][[1]] <- soil.analysis.node
    }
    if (soil.child == "InitialWater") {
      edited.child <- "InitialWater"
      wiwn <- grepl("InitialWater", soil.node0)
      soil.initialwater.node <- soil.node0[wiwn][[1]]
      siw.parms <- c("PercentMethod", "FractionFull",
                     "DepthWetSoil")
      parm <- match.arg(parm, choices = siw.parms)
      soil.initialwater.node[[parm]] <- value
      soil.node[[1]]$Children[wiwn][[1]] <- soil.initialwater.node
    }
    if (soil.child == "Sample") {
      edited.child <- "Sample"
      wsn <- grepl("Sample", soil.node0)
      soil.sample.node <- soil.node0[wsn][[1]]
      for (i in 1:length(soil.sample.node[[parm]])) {
        soil.sample.node[[parm]][[i]] <- value[i]
      }
      soil.node[[1]]$Children[wsn][[1]] <- soil.sample.node
    }
    core.zone.node[wsn] <- soil.node
  }
  if (node == "SurfaceOrganicMatter") {
    wsomn <- grepl("Models.Surface.SurfaceOrganicMatter",
                   core.zone.node)
    som.node <- core.zone.node[wsomn][[1]]
    if (som.node$Name != "SurfaceOrganicMatter") {
      stop("Wrong node")
    }
    som.node[[parm]] <- value
    core.zone.node[wsomn][[1]] <- som.node
  }
  if (node == "MicroClimate") {
    wmcn <- grepl("Models.MicroClimate", core.zone.node)
    microclimate.node <- core.zone.node[wmcn][[1]]
    if (microclimate.node$Name != "MicroClimate") {
      stop("Wrong node")
    }
    microclimate.node[[parm]] <- value
    core.zone.node[wmcn][[1]] <- microclimate.node
  }
  if (node == "Crop") {
    wmmn <- grepl("Models.Manager", core.zone.node)
    manager.node <- core.zone.node[wmmn]
    wcn <- grepl("CultivarName", manager.node)
    crop.node <- manager.node[wcn][[1]]$Parameters
    for (i in 1:length(crop.node)) {
      if (crop.node[[i]]$Key == parm) {
        crop.node[[i]]$Value <- value
      }
    }
    core.zone.node[wmmn][wcn][[1]]$Parameters <- crop.node
  }
  if (node == "Other") {
    upp <- strsplit(parm.path, ".", fixed = TRUE)[[1]]
    upp.lngth <- length(upp)
    if (upp.lngth < 5)
      stop("Parameter path too short?")
    if (upp.lngth > 10)
      stop("Cannot handle this yet")
    if (apsimx_json$Name != upp[2])
      stop("Simulation root name does not match")
    wl3 <- which(upp[3] == sapply(apsimx_json$Children, function(x) x$Name))
    if (length(wl3) == 0)
      stop("Could not find parameter at level 3")
    n3 <- apsimx_json$Children[[wl3]]
    wl4 <- which(upp[4] == sapply(n3$Children, function(x) x$Name))
    if (length(wl4) == 0)
      stop("Could not find parameter at level 4")
    if (upp.lngth == 5) {
      if (upp[5] %in% names(n3$Children[[wl4]])) {
        apsimx_json$Children[[wl3]]$Children[[wl4]][[upp[5]]] <- value
      }
      else {
        wl5 <- which(upp[5] == sapply(n3$Children[[wl4]]$Children,
                                      function(x) x$Name))
        if (length(wl5) == 0)
          stop("Could not find parameter at level 5")
        apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]][[upp[5]]] <- value
      }
    }
    if (upp.lngth == 6) {
      n4 <- apsimx_json$Children[[wl3]]$Children[[wl4]]
      wl5 <- which(upp[5] == sapply(n4$Children, function(x) x$Name))
      if (length(wl5) == 0)
        stop("Could not find parameter at level 5")
      if (upp[6] %in% names(n4$Children[[wl5]])) {
        apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]][[upp[6]]] <- value
      }
      else {
        if ("Parameters" %in% names(n4$Children[[wl5]])) {
          wp <- grep(upp[6], n4$Children[[wl5]]$Parameters)
          if (length(wp) == 0)
            stop("Could not find parameter at level 6 (Parameter)")
          apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]]$Parameters[[wp]]$Value <- value
        }
        else {
          wl6 <- which(upp[6] == sapply(n4$Children[[wl5]]$Children,
                                        function(x) x$Name))
          if (length(wl6) == 0)
            stop("Could not find parameter at level 6")
          apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]]$Children[[wl6]][[upp[6]]] <- value
        }
      }
    }
    if (upp.lngth == 7) {
      n4 <- apsimx_json$Children[[wl3]]$Children[[wl4]]
      wl5 <- grep(upp[5], n4$Children)
      n5 <- apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]]
      wl6 <- grep(upp[6], n4$Children)
      apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]]$Children[[wl6]][[upp[7]]] <- value
    }
    if (upp.lngth == 8) {
      n4 <- apsimx_json$Children[[wl3]]$Children[[wl4]]
      wl5 <- grep(upp[5], n4$Children)
      n5 <- apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]]
      wl6 <- grep(upp[6], n5$Children)
      n6 <- apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]]$Children[[wl6]]
      wl7 <- grep(upp[7], n6$Children)
      apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]]$Children[[wl6]]$Children[[wl7]][[upp[8]]] <- value
    }
    if (upp.lngth == 9) {
      n4 <- apsimx_json$Children[[wl3]]$Children[[wl4]]
      wl5 <- grep(upp[5], n4$Children)
      n5 <- apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]]
      wl6 <- grep(upp[6], n5$Children)
      n6 <- apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]]$Children[[wl6]]
      wl7 <- grep(upp[7], n6$Children)
      n7 <- apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]]$Children[[wl6]]$Children[[wl7]]
      wl8 <- grep(upp[8], n7$Children)
      apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]]$Children[[wl6]]$Children[[wl7]]$Children[[wl8]][[upp[9]]] <- value
    }
    if (upp.lngth == 10) {
      n4 <- apsimx_json$Children[[wl3]]$Children[[wl4]]
      wl5 <- grep(upp[5], n4$Children)
      n5 <- apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]]
      wl6 <- grep(upp[6], n5$Children)
      n6 <- apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]]$Children[[wl6]]
      wl7 <- grep(upp[7], n6$Children)
      n7 <- apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]]$Children[[wl6]]$Children[[wl7]]
      wl8 <- grep(upp[8], n7$Children)
      n8 <- apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]]$Children[[wl6]]$Children[[wl7]]$Children[[wl8]]
      wl9 <- grep(upp[9], n8$Children)
      apsimx_json$Children[[wl3]]$Children[[wl4]]$Children[[wl5]]$Children[[wl6]]$Children[[wl7]]$Children[[wl8]]$Children[[wl9]][[upp[10]]] <- value
    }
  }
  if (node == 'Cultivar') {
    lvls <- search_apsimx(apsimx_json, 'Models.PMF.Plant, Models', T)

    if(length(grep('Models.PMF.Cultivar, Models', capture.output(str(apsimx_json)), ignore.case = T)) == 0) {
      x <- list(list())
      x[[1]]$`$type` <- 'Models.PMF.Cultivar, Models'
      x[[1]]$Command <- list('[Phenology].Juvenile.Target.FixedValue = 110',
                             '[Phenology].GrainFilling.Target.FixedValue = 550')
      x[[1]]$Name <- value
      x[[1]]$Children <- list()
      x[[1]]$IncludeInDocumentation <- T
      x[[1]]$Enabled <- T
      x[[1]]$ReadOnly <- F
      apsimx_json$Children[[lvls[1]]]$Children[[lvls[2]]]$Children[[lvls[3]]]$Children <- x
      parm <- 'New edited cultivar created'
      value <- 'Example values added'
    } else {
      # Edit existing cultivar
      if (parm == 'Command') if (!is.list(value)) value <- as.list(value)
      apsimx_json$Children[[lvls[1]]]$Children[[lvls[2]]]$Children[[lvls[3]]]$Children[[1]][[parm]] <- value
    }
    node <- "Other"
    parm.path <- ""
    print.path <- F
  }
  if (node == "Manager") {
    wmmn <- grepl("Models.Manager", core.zone.node)
    manager.node <- core.zone.node[wmmn]
    manager.node.names <- sapply(manager.node, FUN = function(x) x$Name)
    if (missing(manager.child))
      stop("need to specify manager.child")
    edited.child <- manager.child
    wmc <- grep(manager.child, manager.node.names)
    if (length(wmc) == 0) {
      manager.node.names <- sapply(manager.node[[1]]$Children,
                                   FUN = function(x) x$Name)
      wmc2 <- grep(manager.child, manager.node.names)
      manager.child.node <- manager.node[[1]]$Children[[wmc2]]$Parameters
    }
    else {
      manager.child.node <- manager.node[[wmc]]$Parameters
    }
    for (i in 1:length(manager.child.node)) {
      if (manager.child.node[[i]]$Key == parm) {
        manager.child.node[[i]]$Value <- value
      }
    }
    if (length(wmc) == 0) {
      manager.node[[1]]$Children[[wmc2]]$Parameters <- manager.child.node
    }
    else {
      manager.node[[wmc]]$Parameters <- manager.child.node
    }
    core.zone.node[wmmn] <- manager.node
  }

  if (node == "Report") {
    if (!parm %in% c("VariableNames", "EventNames"))
      stop ('When node = "Report", parm must be either "VariableNames" or "EventNames".')
    if (class(value) != 'list') {
      warning('value should be a list. It will be coerced.')
      value <- as.list(value)
    }
    tmp <- search_apsimx(apsimx_json, parm)
    lvls <- search_apsimx(apsimx_json, parm, T)

    if (length(lvls) == 2)
      apsimx_json$Children[[lvls[1]]]$Children[[lvls[2]]][[parm]] <- value
    if (length(lvls) == 3)
      apsimx_json$Children[[lvls[1]]]$Children[[lvls[2]]]$Children[[lvls[3]]][[parm]] <- value
    if (length(lvls) == 4)
      apsimx_json$Children[[lvls[1]]]$Children[[lvls[2]]]$Children[[lvls[3]]]$Children[[lvls[4]]][[parm]] <- value
    if (length(lvls) == 5)
      apsimx_json$Children[[lvls[1]]]$Children[[lvls[2]]]$Children[[lvls[3]]]$Children[[lvls[4]]]$Children[[lvls[5]]][[parm]] <- value

    node <- "Other"
    parm.path <- ""
    print.path <- F
  }

  if (node != "Other") {
    parent.node[wcz][[1]]$Children <- core.zone.node
    if (length(wcore) > 1) {
      if (length(root) == 1) {
        apsimx_json$Children[[wcore1]]$Children <- parent.node
      }
      else {
        apsimx_json$Children[[wcore1]]$Children[[wcore2]]$Children <- parent.node
      }
    }
    else {
      apsimx_json$Children[[wcore]]$Children <- parent.node
    }
  }
  if (overwrite == FALSE) {
    wr.path <- paste0(wrt.dir, "/", tools::file_path_sans_ext(file),
                      edit.tag, ".apsimx")
  }
  else {
    wr.path <- paste0(wrt.dir, "/", file)
  }
  jsonlite::write_json(apsimx_json, path = wr.path, pretty = TRUE,
                       digits = NA, auto_unbox = TRUE, null = "null")
  if (verbose) {
    cat("Edited (node): ", node, "\n")
    cat("Edited (child): ", edited.child, "\n")
    cat("Edited parameters: ", parm, "\n")
    cat("New values: ", unlist(value), "\n")
    cat("Created: ", wr.path, "\n")
  }
}

#=============================================================================

# New inspect_apsimx

inspect_apsimx_new <- function (file = "", src.dir = ".",
                                node = c("Clock","Weather", "Soil", "SurfaceOrganicMatter",
                                         "Cultivar", "MicroClimate", "Crop", "Manager", "Other", "Report"),
                                soil.child = c("Metadata", "Water", "InitialWater",
                                               "Chemical", "Physical", "Analysis",
                                               "SoilWater", "InitialN", "CERESSoilTemperature",
                                               "Sample", "Nutrient", "Organic"), parm = NULL,
                                digits = 3, print.path = FALSE, root)
{
  apsimx:::.check_apsim_name(file)
  file.names <- dir(path = src.dir, pattern = ".apsimx$",
                    ignore.case = TRUE)
  if (length(file.names) == 0) {
    stop("There are no .apsimx files in the specified directory to inspect.")
  }
  node <- match.arg(node)
  soil.child <- match.arg(soil.child)
  if (soil.child %in% c("Nutrient"))
    stop("Not implemented yet")
  file <- match.arg(file, file.names)
  apsimx_json <- jsonlite::read_json(paste0(src.dir, "/",
                                            file))
  parm.path.0 <- paste0(".", apsimx_json$Name)
  fcsn <- grep("Models.Core.Simulation", apsimx_json$Children,
               fixed = TRUE)
  if (length(fcsn) > 1) {
    if (missing(root)) {
      cat("Simulation structure: \n")
      str_list(apsimx_json)
      stop("more than one simulation found and no root node label has been specified \n select one of the children names above")
    }
    else {
      if (length(root) == 1) {
        nms <- vapply(apsimx_json$Children, FUN = function(x) x$Name,
                      FUN.VALUE = "character")
        fcsn <- grep(as.character(root), nms)
        parm.path.1 <- paste0(parm.path.0, ".",
                              apsimx_json$Children[[fcsn]]$Name)
        parent.node <- apsimx_json$Children[[fcsn]]$Children
        if (length(fcsn) == 0 || length(fcsn) > 1)
          stop("no root node label found or root is not unique")
      }
      else {
        nms1 <- vapply(apsimx_json$Children, FUN = function(x) x$Name,
                       FUN.VALUE = "character")
        fcsn1 <- grep(as.character(root[1]), nms1)
        root.node.0 <- apsimx_json$Children[[fcsn1]]
        root.node.0.child.names <- vapply(root.node.0$Children,
                                          function(x) x$Name, FUN.VALUE = "character")
        fcsn2 <- grep(as.character(root[2]), root.node.0.child.names)
        parent.node <- apsimx_json$Children[[fcsn1]]$Children[[fcsn2]]$Children
        parm.path.1 <- paste0(parm.path.0, ".",
                              apsimx_json$Children[[fcsn1]]$Children[[fcsn2]])
      }
    }
  }
  else {
    parent.node <- apsimx_json$Children[[fcsn]]$Children
    parm.path.1 <- paste0(parm.path.0, ".", apsimx_json$Children[[fcsn]]$Name)
  }

  if (node == "Clock") {
    wlc <- function(x) grepl("Clock", x$Name, ignore.case = TRUE)
    wlcl <- sapply(parent.node, FUN = wlc)
    clock.node <- as.list(parent.node[wlcl])[[1]]
    start.name <- grep("start", names(clock.node),
                       ignore.case = TRUE, value = TRUE)
    end.name <- grep("end", names(clock.node), ignore.case = TRUE,
                     value = TRUE)
    cat("Start:", clock.node[[start.name]], "\n")
    cat("End:", clock.node[[end.name]], "\n")
    parm.path <- paste0(parm.path.1, ".", parent.node[wlcl][[1]]$Name)
  }
  if (node == "Weather") {
    wlw <- function(x) grepl("Weather", x$Name)
    wlwl <- sapply(parent.node, FUN = wlw)
    weather.node <- parent.node[wlwl]
    gf1 <- function(x) grep(".met$", x, value = TRUE)
    cat("Met file:", as.character(sapply(weather.node,
                                         gf1)), "\n")
    parm.path <- paste0(parm.path.1, ".", parent.node[wlwl][[1]]$Name)
  }
  wcz <- grepl("Models.Core.Zone", parent.node)
  core.zone.node <- parent.node[wcz][[1]]$Children
  parm.path.2 <- paste0(parm.path.1, ".", parent.node[wcz][[1]]$Name)
  if (node == "Soil") {
    wsn <- grepl("Models.Soils.Soil", core.zone.node)
    soil.node <- core.zone.node[wsn]
    parm.path.2.1 <- paste0(parm.path.2, ".", soil.node[[1]]$Name)
    cat("Soil Type: ", soil.node[[1]]$SoilType, "\n")
    cat("Latitude: ", soil.node[[1]]$Latitude, "\n")
    cat("Longitude: ", soil.node[[1]]$Longitude, "\n")
    if (length(soil.node) != 1)
      stop("soil.node not equal to one")
    soil.children.names <- sapply(soil.node[[1]]$Children,
                                  function(x) x$Name)
    cat("Soil children:", soil.children.names, "\n")
    if (soil.child == "Metadata") {
      parm.path <- parm.path.2.1
      metadata <- NULL
      for (i in names(soil.node[[1]])) {
        if (i %in% c("Name", "Children",
                     "IncludeInDocumentation", "Enabled",
                     "ReadOnly"))
          next
        val <- as.character(ifelse(is.null(soil.node[[1]][[i]]),
                                   NA, soil.node[[1]][[i]]))
        if (!is.na(val) && nchar(val) > options()$width -
            30)
          val <- paste(strtrim(val, options()$width -
                                 30), "...")
        metadata <- rbind(metadata, data.frame(parm = i,
                                               value = val))
      }
      if (missing(parm)) {
        print(knitr::kable(metadata, longtable = FALSE))
      }
      else {
        if (!(parm %in% metadata[["parm"]]))
          stop("parm does not match a parameter in metadata")
        print(knitr::kable(metadata[metadata$parm ==
                                      parm, ]))
      }
    }
    else {
      wsc <- grep(soil.child, soil.children.names)
      if (length(wsc) == 0)
        stop("soil.child likely not present")
      selected.soil.node.child <- soil.node[[1]]$Children[wsc]
    }
    first.level.soil <- c("Water", "Physical",
                          "Chemical", "Analysis", "InitialWater",
                          "InitialN", "SoilWater", "Analysis",
                          "CERESSoilTemperature", "Organic")
    if (soil.child %in% first.level.soil) {
      parm.path <- paste0(parm.path.2.1, ".", selected.soil.node.child[[1]]$Name)
      enms <- c("IncludeInDocumentation", "Enabled",
                "ReadOnly", "Children", "Name")
      cnms <- setdiff(names(selected.soil.node.child[[1]]),
                      enms)
      soil.d1 <- NULL
      soil.d2 <- NULL
      col.nms <- NULL
      for (ii in cnms) {
        tmp <- selected.soil.node.child[[1]][ii][[1]]
        if (length(tmp) == 0)
          next
        if (length(tmp) == 1) {
          soil.d1 <- rbind(soil.d1, data.frame(parm = ii,
                                               value = as.character(tmp)))
        }
        if (length(tmp) > 1) {
          col.nms <- c(col.nms, ii)
          vals <- as.vector(unlist(tmp))
          soil.d2 <- cbind(soil.d2, vals)
        }
      }
      if (missing(parm)) {
        if (!is.null(soil.d1))
          print(knitr::kable(soil.d1, digits = digits))
        if (!is.null(soil.d2)) {
          soil.d2 <- as.data.frame(soil.d2)
          names(soil.d2) <- col.nms
          print(knitr::kable(soil.d2, digits = digits))
        }
      }
      else {
        if (!is.null(soil.d1))
          print(knitr::kable(soil.d1[soil.d1$parm ==
                                       parm, ], digits = digits))
        if (!is.null(soil.d2)) {
          soil.d2 <- as.data.frame(soil.d2)
          names(soil.d2) <- col.nms
          print(knitr::kable(soil.d2[soil.d2$parm ==
                                       parm, ], digits = digits))
        }
      }
    }
  }
  if (node == "SurfaceOrganicMatter") {
    wsomn <- grepl("Models.Surface.SurfaceOrganicMatter",
                   core.zone.node)
    som.node <- core.zone.node[wsomn][[1]]
    parm.path <- paste0(parm.path.2, ".", som.node$Name)
    som.d <- data.frame(parm = names(som.node)[2:8], value = as.vector(unlist(som.node)[2:8]))
    print(knitr::kable(som.d, digits = digits))
  }
  if (node == "MicroClimate") {
    wmcn <- grepl("Models.MicroClimate", core.zone.node)
    microclimate.node <- core.zone.node[wmcn][[1]]
    parm.path <- paste0(parm.path.2, ".", microclimate.node$Name)
    microclimate.d <- data.frame(parm = names(microclimate.node)[2:9],
                                 value = as.vector(unlist(microclimate.node)[2:9]))
    print(knitr::kable(microclimate.d, digits = digits))
  }
  if (node == "Crop") {
    wmmn <- grepl("Models.Manager", core.zone.node)
    manager.node <- core.zone.node[wmmn]
    wcn <- grepl("CultivarName", manager.node)
    crop.node <- manager.node[wcn][[1]]$Parameters
    parm.path <- paste0(parm.path.2, ".", manager.node[wcn][[1]]$Name)
    mat <- matrix(NA, nrow = length(crop.node), ncol = 2,
                  dimnames = list(NULL, c("parm", "value")))
    j <- 1
    for (i in 1:length(crop.node)) {
      mat[j, 1] <- crop.node[[i]]$Key
      mat[j, 2] <- crop.node[[i]]$Value
      j <- j + 1
    }
    print(knitr::kable(as.data.frame(mat), digits = digits))
  }
  if (node == 'Cultivar') {
    if (length(grep('Models.PMF.Cultivar, Models', capture.output(str(apsimx_json)), ignore.case = T)) > 0) {
      # There is at least one edited cultivar
      tmp <- search_apsimx(apsimx_json, keyword = 'Models.PMF.Cultivar, Models')
      cat('Name = ', tmp$Name)
      cat("\n")
      print(knitr::kable(data.frame(Command = unlist(tmp$Command))))
      cat("\n")
    } else {
      cat("No edited cultivars. Use function edit_apsimx() to add one.\n")
    }
    parm.path <- ""
    print.path <- F
  }
  if (node == "Manager") {
    wmmn <- grepl("Models.Manager", core.zone.node)
    manager.node <- core.zone.node[wmmn]
    parm.path <- parm.path.2
    manager.node.names <- sapply(manager.node, FUN = function(x) x$Name)
    cat("Management Scripts: ", manager.node.names,
        "\n\n")
    if (!is.null(parm)) {
      parm1 <- parm[[1]]
      position <- parm[[2]]
      find.manager <- grep(parm1, manager.node.names, ignore.case = TRUE)
      selected.manager.node <- manager.node.names[find.manager]
      parm.path <- paste0(parm.path.2, ".", selected.manager.node)
      if (is.na(position)) {
        ms.params <- manager.node[[find.manager]]$Parameters
        if (length(ms.params) == 0)
          warning("parameter not found")
        mat <- matrix(NA, ncol = 2, nrow = length(ms.params),
                      dimnames = list(NULL, c("parm", "value")))
        if (length(ms.params) > 0) {
          for (j in 1:length(ms.params)) {
            mat[j, 1] <- ms.params[[j]]$Key
            mat[j, 2] <- ms.params[[j]]$Value
          }
        }
        cat("Name: ", selected.manager.node, "\n")
        print(knitr::kable(as.data.frame(mat), digits = digits))
        cat("\n")
      }
      if (!is.na(position)) {
        ms.params <- manager.node[[find.manager]]$Parameters
        if (length(ms.params) == 0)
          warning("no parameters found")
        mat <- matrix(NA, ncol = 2, nrow = length(position),
                      dimnames = list(NULL, c("parm", "value")))
        k <- 1
        for (j in 1:length(ms.params)) {
          if (j == position) {
            mat[k, 1] <- ms.params[[j]]$Key
            mat[k, 2] <- ms.params[[j]]$Value
            k <- k + 1
          }
        }
        cat("Name: ", selected.manager.node, "\n")
        parm2 <- ms.params[[position]]$Key
        cat("Key:", ms.params[[position]]$Key,
            "\n")
        print(knitr::kable(as.data.frame(mat), digits = digits))
        cat("\n")
      }
    }
  }
  if (node == "Other") {
    tmp <- core.zone.node
    parm.path.2.1 <- parm.path.2
    if (is.null(parm))
      stop("'parm' should be provided when node = 'Other'")
    if (length(parm) == 1L)
      stop("'parm' should be a list of length 2 or more")
    for (i in 1:(length(parm) - 1)) {
      nms <- sapply(tmp, function(x) x$Name)
      wcp <- grep(parm[[i]], nms)
      if (length(wcp) == 0) {
        cat("Names: ", nms, "\n")
        cat("parm[[i]]", parm[[i]], "\n")
        stop("Parameter not found")
      }
      tmp <- tmp[[wcp]]
      if (!is.null(tmp$Children))
        tmp <- tmp$Children
      parm.path.2.1 <- paste0(parm.path.2.1, ".",
                              nms[wcp])
    }
    if (!is.null(tmp$Parameters)) {
      wp <- grep(parm[[length(parm)]], tmp$Parameters)
      tmp2 <- tmp$Parameters[[wp]]
      parm.path <- paste0(parm.path.2.1, ".", tmp2$Key)
      print(knitr::kable(as.data.frame(tmp2)))
    }
    else {
      parm.path <- parm.path.2.1
      unpack_node(tmp)
    }
  }
  if (node == "Report") {
    tmp <- search_apsimx(apsimx_json, keyword = 'VariableNames')
    print(knitr::kable(data.frame(VariableNames = unlist(tmp$VariableNames))))
    cat("\n")
    print(knitr::kable(data.frame(EventNames = unlist(tmp$EventNames))))
    parm.path <- ""
    print.path <- F
  }
  if (print.path && node != "Other") {
    if (!missing(parm)) {
      if (length(parm) == 1) {
        parm.path <- paste0(parm.path, ".", parm)
      }
      else {
        if (!is.na(position)) {
          parm.path <- paste0(parm.path, ".", parm2)
        }
      }
    }
    cat("Parm path:", parm.path, "\n")
  }
  else {
    if (print.path)
      cat("Parm path:", parm.path, "\n")
  }
  invisible(parm.path)
}


#=============================================================================

# Version of apsimx that does not check for white spaces

apsimx <- function (file = "", src.dir = ".", silent = FALSE,
                    value = "report", cleanup = FALSE, simplify = TRUE,
                    xargs)
{
  if (file == "")
    stop("need to specify file name")
  apsimx:::.check_apsim_name(file)
  #apsimx:::.check_apsim_name(normalizePath(src.dir))
  file.names <- dir(path = src.dir, pattern = ".apsimx$",
                    ignore.case = TRUE)
  if (length(file.names) == 0) {
    stop("There are no .apsimx files in the specified directory to run.")
  }
  file <- match.arg(file, file.names)
  file.name.path <- file.path(src.dir, file)
  ada <- apsimx:::auto_detect_apsimx()
  dotnet.flag <- apsimx::apsimx.options$dotnet
  mono.flag <- apsimx::apsimx.options$mono
  if (!missing(xargs)) {
    dotnet.flag <- xargs$dotnet
    mono.flag <- xargs$mono
    if (!is.na(xargs$exe.path))
      ada <- xargs$exe.path
  }
  if (.Platform$OS.type == "unix") {
    if (dotnet.flag) {
      run.strng <- paste("dotnet", ada, file.name.path)
    }
    if (mono.flag) {
      mono <- system("which mono", intern = TRUE)
      run.strng <- paste(mono, ada, file.name.path)
    }
    if (isFALSE(dotnet.flag) && isFALSE(mono.flag)) {
      run.strng <- paste(ada, file.name.path)
    }
    if (!missing(xargs))
      run.strng <- paste(run.strng, xargs$xargs.string)
    res <- system(command = run.strng, ignore.stdout = silent,
                  intern = TRUE)
  }
  if (.Platform$OS.type == "windows") {
    run.strng <- paste0(ada, " ", file.name.path)
    if (!missing(xargs))
      run.strng <- paste(run.strng, xargs$xargs.string)
    shell(cmd = run.strng, translate = TRUE, intern = TRUE)
  }
  if (value != "none") {
    ans <- read_apsimx(file = sub("apsimx", "db",
                                  file), src.dir = src.dir, value = value, simplify = simplify)
  }
  else {
    if (value == "none" && !silent) {
      cat("APSIM created .db files, but nothing is returned \n")
    }
  }
  if (cleanup) {
    if (value == "none")
      stop("do not clean up if you choose value = 'none' ")
    file.remove(paste0(src.dir, "/", sub("apsimx",
                                         "db", file)))
  }
  if (value != "none")
    return(ans)
}
